#include "cillib.h"

namespace FDU {
namespace rt_cil_lib {
CilBase::~CilBase() {}
} // namespace rt_cil_lib
} // namespace FDU