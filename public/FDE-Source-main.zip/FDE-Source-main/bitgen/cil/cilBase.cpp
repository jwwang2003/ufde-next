#include "cilBase.h"

namespace FDU {
namespace cil_lib {
CilBase::~CilBase() {}
} // namespace cil_lib
} // namespace FDU