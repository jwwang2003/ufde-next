
#include "netlist.hpp"

namespace FudanFPGA {
namespace netlist {
namespace fileio {
// void VerilogLoader::load(std::istream& ostrm/* source name*/, const
// std::string& lib/*lib_name*/) {
//
// }

}
} // namespace netlist
} // namespace FudanFPGA